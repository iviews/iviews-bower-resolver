var x = 2
console.log(x)
